<?php

// Must begin with a number for Debian packaging requirements
// Must use single-quotes for packaging script to work
return '0.34.1'; // Update Tracer::VERSION too
