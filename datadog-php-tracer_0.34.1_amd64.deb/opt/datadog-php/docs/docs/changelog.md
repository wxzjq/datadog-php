# Changelog

This page has been moved to [CONTRIBUTING.md](../CONTRIBUTING.md).
