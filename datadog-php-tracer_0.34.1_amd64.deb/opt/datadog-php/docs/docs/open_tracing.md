# Datadog PHP OpenTracing Support

This page has been moved to the [advanced-instrumentation documentation](https://docs.datadoghq.com/tracing/advanced_usage/?tab=php#opentracing).
